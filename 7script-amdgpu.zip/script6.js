#include <iostream>
#include <random>
#include <string>
#include <fstream>
#include <thread>
#include <vector>

extern "C" {
    #include "bitcoin.h"
}

std::string generate_address() {
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<uint64_t> dis(0x20000000000000000, 0x3ffffffffffffffff);
    uint64_t val = dis(gen);

    std::stringstream ss;
    ss << std::hex << val;
    std::string result = ss.str();
    result = std::string(47 + result.length(), '0') + result;

    std::string priv = result;
    std::string pub = privtopub(priv.c_str());
    std::string pubkey1 = encode_pubkey(privtopub(priv.c_str()), "bin_compressed");
    std::string addr = pubtoaddr(pubkey1.c_str());

    return addr;
}

void check_address() {
    std::chrono::steady_clock::time_point start_time = std::chrono::steady_clock::now();
    int keys_generated = 0;
    double g = 0.0;

    while (true) {
        std::string addr = generate_address();
        keys_generated++;

        if (addr == "13zb1hQbWVsc2S7ZTZnP2G4undNNpdh5so") {
            std::cout << "found!! " << addr << std::endl;
            std::string k1 = addr;
            std::string k2 = privtopub(addr.c_str());
            std::string k3 = addr;

            std::ofstream file("boom.txt", std::ios::app);
            file << "Private key: " << k1 << std::endl;
            file << "Public key: " << k2 << std::endl;
            file << "Address: " << k3 << std::endl << std::endl;
            file.close();

            break;
        } else {
            std::chrono::steady_clock::time_point current_time = std::chrono::steady_clock::now();
            double elapsed_time = std::chrono::duration_cast<std::chrono::seconds>(current_time - start_time).count();

            if (elapsed_time >= 1) {
                double speed = keys_generated / elapsed_time;
                g = speed;
                keys_generated = 0;
                start_time = std::chrono::steady_clock::now();
            }

            std::cout << "searching... " << addr << " Speed: " << g << " keys/second" << std::endl;
        }
    }
}

int main(int argc, char** argv) {
    int num_processes = std::thread::hardware_concurrency();
    std::vector<std::thread> threads;

    for (int i = 0; i < num_processes; i++) {
        threads.emplace_back(check_address);
    }

    for (auto& thread : threads) {
        thread.join();
    }

    return 0;
}