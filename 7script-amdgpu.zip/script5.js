#include <iostream>
#include <random>
#include <string>
#include <fstream>
#include <thread>
#include <vector>
#include <CL/cl.hpp>

extern "C" {
    #include "bitcoin.h"
}

std::string generate_address() {
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<uint64_t> dis(0x20000000000000000, 0x3ffffffffffffffff);
    uint64_t val = dis(gen);

    std::stringstream ss;
    ss << std::hex << val;
    std::string result = ss.str();
    result = std::string(47 + result.length(), '0') + result;

    std::string priv = result;
    std::string pub = privtopub(priv.c_str());
    std::string pubkey1 = encode_pubkey(privtopub(priv.c_str()), "bin_compressed");
    std::string addr = pubtoaddr(pubkey1.c_str());

    return addr;
}

void check_address() {
    std::chrono::steady_clock::time_point start_time = std::chrono::steady_clock::now();
    int keys_generated = 0;
    double g = 0.0;

    // Get available OpenCL platforms
    std::vector<cl::Platform> platforms;
    cl::Platform::get(&platforms);

    // Select the first available platform
    cl::Platform platform = platforms[0];

    // Get available devices on the selected platform
    std::vector<cl::Device> devices;
    platform.getDevices(CL_DEVICE_TYPE_GPU, &devices);

    // Select the first available device
    cl::Device device = devices[0];

    // Create an OpenCL context
    cl::Context context({device});

    // Create an OpenCL command queue
    cl::CommandQueue queue(context, device);

    // Load and compile the OpenCL kernel code
    std::ifstream kernelFile("bitcoin.cl");
    std::string kernelCode(std::istreambuf_iterator<char>(kernelFile), (std::istreambuf_iterator<char>()));
    cl::Program::Sources sources(1, std::make_pair(kernelCode.c_str(), kernelCode.length() + 1));
    cl::Program program(context, sources);
    program.build({device});

    // Create an OpenCL kernel
    cl::Kernel kernel(program, "check_address_kernel");

    while (true) {
        std::string addr = generate_address();
        keys_generated++;

        if (addr == "13zb1hQbWVsc2S7ZTZnP2G4undNNpdh5so") {
            std::cout << "found!! " << addr << std::endl;
            std::string k1 = addr;
            std::string k2 = privtopub(addr.c_str());
            std::string k3 = addr;

            std::ofstream file("boom.txt", std::ios::app);
            file << "Private key: " << k1 << std::endl;
            file << "Public key: " << k2 << std::endl;
            file << "Address: " << k3 << std::endl << std::endl;
            file.close();

            break;
        } else {
            std::chrono::steady_clock::time_point current_time = std::chrono::steady_clock::now();
            double elapsed_time = std::chrono::duration_cast<std::chrono::seconds>(current_time - start_time).count();

            if (elapsed_time >= 1) {
                double speed = keys_generated / elapsed_time;
                g = speed;
                keys_generated = 0;
                start_time = std::chrono::steady_clock::now();
            }

            // Set the kernel arguments
            cl::Buffer addrBuffer(context, CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR, addr.size() + 1, (void*)addr.c_str());
            cl::Buffer resultBuffer(context, CL_MEM_WRITE_ONLY, sizeof(int));
            kernel.setArg(0, addrBuffer);
            kernel.setArg(1, resultBuffer);

            // Enqueue the kernel for execution
            queue.enqueueNDRangeKernel(kernel, cl::NullRange, cl::NDRange(1), cl::NullRange);

            // Read the result from the device
            int result;
            queue.enqueueReadBuffer(resultBuffer, CL_TRUE, 0, sizeof(int), &result);

            std::cout << "searching... " << addr << " Speed: " << g << " keys/second" << std::endl;
        }
    }
}

int main(int argc, char** argv) {
    int num_processes = std::thread::hardware_concurrency();
    std::vector<std::thread> threads;

    for (int i = 0; i < num_processes; i++) {
        threads.emplace_back(check_address);
    }

    for (auto& thread : threads) {
        thread.join();
    }

    return 0;
}
