#include <iostream>
#include <random>
#include <vector>
#include <chrono>
#include <fstream>

std::string generate_address() {
    uint64_t low = 0x1000000000000000;
    uint64_t high = 0x1fffffffffffffff;
    std::random_device rd;
    std::mt19937_64 gen(rd());
    std::uniform_int_distribution<uint64_t> dist(low, high);
    uint64_t val = dist(gen);
    std::string result = std::to_string(val);
    result.insert(result.begin(), 46 - result.size(), '0');
    std::string priv = result;
    std::string pub = privtopub(priv); // Assuming privtopub function is defined
    std::string pubkey1 = encode_pubkey(privtopub(priv), "bin_compressed"); // Assuming encode_pubkey function is defined
    std::string addr = pubtoaddr(pubkey1); // Assuming pubtoaddr function is defined
    return addr + " " + result;
}

void check_address() {
    auto start_time = std::chrono::steady_clock::now();
    int keys_generated = 0;
    double g = 0.0;

    while (true) {
        std::string result = generate_address();
        std::string addr = result.substr(0, 34);

        keys_generated++;

        if (addr == "19vkiEajfhuZ8bs8Zu2jgmC6oqZbWqhxhG") {
            std::cout << "found!! " << addr << " " << result << std::endl;
            std::string k1 = result;
            std::string k2 = privtopub(result); // Assuming privtopub function is defined
            std::string k3 = addr;

            std::ofstream file("boom.txt", std::ios::app);
            file << "Private key: " << k1 << "\n" << "Public key: " << k2 << "\n" << "Address: " << k3 << "\n\n";
            file.close();

            break; // Stop the loop when the result is found
        }
        else {
            auto elapsed_time = std::chrono::steady_clock::now() - start_time;
            double elapsed_seconds = std::chrono::duration_cast<std::chrono::seconds>(elapsed_time).count();

            if (elapsed_seconds >= 1) {
                double speed = keys_generated / elapsed_seconds;
                g = speed;
                keys_generated = 0;
                start_time = std::chrono::steady_clock::now();
            }

            std::cout << "searching... " << addr << " " << result << " Speed: " << g << " keys/second" << std::endl;
        }
    }
}

int main(int argc, char* argv[]) {
    int num_processes = std::thread::hardware_concurrency();
    std::vector<std::thread> threads;

    bool use_cuda = false; // Set this to true if you want to use GPU

    if (use_cuda) {
        std::cout << "Using GPU" << std::endl;
    }
    else {
        std::cout << "Using CPU" << std::endl;
    }

    for (int i = 0; i < num_processes; i++) {
        std::thread t(check_address);
        threads.push_back(std::move(t));
    }

    for (auto& t : threads) {
        t.join();
    }

    return 0;
}
