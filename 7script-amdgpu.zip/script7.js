#include <iostream>
#include <random>
#include <string>
#include <fstream>
#include <CL/cl.hpp>

std::string generate_address() {
    std::random_device rd;
    std::mt19937 gen(rd());
    std::uniform_int_distribution<uint64_t> dis(0x20000000000000000, 0x3ffffffffffffffff);
    uint64_t val = dis(gen);

    std::stringstream ss;
    ss << std::hex << val;
    std::string result = ss.str();
    result = std::string(47 + result.length() - 2, '0') + result;

    std::string priv = result;
    std::string pub = privtopub(priv);
    std::string pubkey1 = encode_pubkey(privtopub(priv), "bin_compressed");
    std::string addr = pubtoaddr(pubkey1);

    return addr;
}

void check_address() {
    cl_int err;
    cl::Context context(CL_DEVICE_TYPE_GPU);
    std::vector<cl::Device> devices = context.getInfo<CL_CONTEXT_DEVICES>();
    cl::CommandQueue queue(context, devices[0], 0, &err);

    cl::Program::Sources sources;
    std::string kernelCode =
        "void kernel checkAddress(global char* addr) {"
        "    uint64_t low = 0x20000000000000000;"
        "    uint64_t high = 0x3ffffffffffffffff;"
        "    uint64_t val = low + get_global_id(0);"
        "    char result[64];"
        "    sprintf(result, \"%lx\", val);"
        "    result[47 + strlen(result)] = '\\0';"
        "    if (strcmp(addr, result) == 0) {"
        "        printf(\"found!! %s\\n\", result);"
        "        char k1[64];"
        "        strcpy(k1, result);"
        "        char k2[128];"
        "        strcpy(k2, privtopub(result));"
        "        char k3[128];"
        "        strcpy(k3, addr);"
        "        FILE* file = fopen(\"boom.txt\", \"a\");"
        "        fprintf(file, \"Private key: %s\\n\", k1);"
        "        fprintf(file, \"Public key: %s\\n\", k2);"
        "        fprintf(file, \"Address: %s\\n\\n\", k3);"
        "        fclose(file);"
        "    }"
        "}";

    sources.push_back({kernelCode.c_str(), kernelCode.length()});
    cl::Program program(context, sources);
    err = program.build(devices);

    cl::Kernel kernel(program, "checkAddress", &err);

    std::string addr = generate_address();
    const int numKeys = 1000000;

    cl::Buffer addrBuffer(context, CL_MEM_READ_ONLY | CL_MEM_COPY_HOST_PTR,
                          addr.length() + 1, (void*)addr.c_str(), &err);

    kernel.setArg(0, addrBuffer);

    cl::Event event;

    for (int i = 0; i < numKeys; i++) {
        err = queue.enqueueNDRangeKernel(kernel, cl::NullRange, cl::NDRange(1), cl::NullRange, nullptr, &event);
        event.wait();

        char found[6];
        err = queue.enqueueReadBuffer(addrBuffer, CL_TRUE, 0, 6, found);
        if (strcmp(found, "found") == 0) {
            break;
        }
    }
}

int main(int argc, char** argv) {
    int numProcesses = std::thread::hardware_concurrency();

    std::vector<std::thread> threads;
    for (int i = 0; i < numProcesses; i++) {
        threads.emplace_back(check_address);
    }

    for (auto& thread : threads) {
        thread.join();
    }

    return 0;
}